import 'package:flutter/material.dart';
import '/Button/BottomNavigationBar.dart';
import 'switchWeek.dart';
import 'addDiary.dart';
import 'editDiary.dart';

class DiaryPage extends StatefulWidget {
  const DiaryPage({Key? key}) : super(key: key);

  @override
  State<DiaryPage> createState() => _DiaryPageState();
}

class DiaryEntry {
  final String title;
  final String content;
  final DateTime date;

  DiaryEntry({
    required this.title,
    required this.content,
    required this.date,
  });
}

class _DiaryPageState extends State<DiaryPage> {
  DateTime selectedDate = DateTime.now(); // Tanggal yang dipilih
  bool isDayView = true;
  int currentNavIndex = 1;

  List<DiaryEntry> entries = [
    // Tanggal 29 April 2025
    DiaryEntry(
      title: "Pagi yang Cerah",
      content: "Pagi ini ketika matahari bersinar masuk melalui jendela, aku merasa semangat hidup kembali mengalir dalam darahku.",
      date: DateTime(2025, 4, 29),
    ),
    DiaryEntry(
      title: "Mulai Hari dengan Semangat",
      content: "Aku memulai hari dengan rencana yang jelas. Semangatku untuk menyelesaikan pekerjaan hari ini sangat besar.",
      date: DateTime(2025, 4, 29),
    ),
    DiaryEntry(
      title: "Menjaga Keseimbangan",
      content: "Aku berusaha menjaga keseimbangan antara pekerjaan dan waktu pribadi, agar bisa lebih produktif.",
      date: DateTime(2025, 4, 29),
    ),
    DiaryEntry(
      title: "Berkendara di Pagi Hari",
      content: "Pagi ini aku berkendara melalui jalan yang sepi. Rasanya menyenangkan untuk memulai hari dengan ketenangan.",
      date: DateTime(2025, 4, 29),
    ),

    // Tanggal 30 April 2025
    DiaryEntry(
      title: "Hari yang Sibuk",
      content: "Hari ini sangat sibuk dengan pekerjaan yang menumpuk, tapi aku merasa puas karena semuanya selesai tepat waktu.",
      date: DateTime(2025, 4, 30),
    ),
    DiaryEntry(
      title: "Berbagi Waktu dengan Teman",
      content: "Aku menghabiskan waktu dengan teman-teman, berbicara tentang berbagai hal yang menyenangkan.",
      date: DateTime(2025, 4, 30),
    ),
    DiaryEntry(
      title: "Kejar Deadline",
      content: "Aku berusaha keras mengejar deadline hari ini. Beberapa kali terhalang oleh tugas yang tak terduga, tapi akhirnya berhasil.",
      date: DateTime(2025, 4, 30),
    ),
    DiaryEntry(
      title: "Berkumpul dengan Keluarga",
      content: "Setelah hari yang sibuk, aku berkumpul dengan keluarga untuk makan malam bersama.",
      date: DateTime(2025, 4, 30),
    ),

    // Tanggal 1 Mei 2025
    DiaryEntry(
      title: "Menahan Emosi",
      content: "Hari ini, amarahku seperti api kecil yang tersembunyi di balik kabut. Bukan ledakan besar, tetapi bara yang menyala perlahan.",
      date: DateTime(2025, 5, 1),
    ),
    DiaryEntry(
      title: "Refleksi Pagi",
      content: "Pagi ini aku melakukan refleksi diri, berusaha untuk lebih sabar dan memahami perasaan orang lain.",
      date: DateTime(2025, 5, 1),
    ),
    DiaryEntry(
      title: "Berbagi Kisah",
      content: "Aku berbagi kisah masa kecilku dengan teman-teman. Rasanya menyenangkan mengenang hal-hal sederhana yang dulu aku anggap biasa.",
      date: DateTime(2025, 5, 1),
    ),
    DiaryEntry(
      title: "Pagi yang Tenang",
      content: "Setelah beberapa hari yang penuh, pagi ini sangat tenang dan penuh kedamaian.",
      date: DateTime(2025, 5, 1),
    ),

    // Tanggal 2 Mei 2025
    DiaryEntry(
      title: "Pagi yang Cerah",
      content: "Pagi ini ketika matahari bersinar masuk melalui jendela, aku merasa semangat hidup kembali mengalir dalam darahku.",
      date: DateTime(2025, 5, 2),
    ),
    DiaryEntry(
      title: "Menemukan Ketenangan",
      content: "Meskipun pekerjaan menumpuk, aku merasa tenang karena bisa fokus dan menyelesaikan semuanya dengan baik.",
      date: DateTime(2025, 5, 2),
    ),
    DiaryEntry(
      title: "Mengatur Waktu",
      content: "Hari ini aku belajar cara mengatur waktu dengan lebih baik, agar bisa menyelesaikan semua tugas dengan efektif.",
      date: DateTime(2025, 5, 2),
    ),
    DiaryEntry(
      title: "Bersantai Setelah Pekerjaan",
      content: "Setelah beberapa hari sibuk, aku akhirnya bisa bersantai dan menikmati waktu untuk diriku sendiri.",
      date: DateTime(2025, 5, 2),
    ),

    // Tanggal 3 Mei 2025
    DiaryEntry(
      title: "Petang yang Tenang",
      content: "Duduk di teras sambil menikmati petang yang tenang adalah cara favoritku mengakhiri hari.",
      date: DateTime(2025, 5, 3),
    ),
    DiaryEntry(
      title: "Kesibukan Pagi",
      content: "Pagi ini aku menjalani beberapa rapat dan sangat sibuk, namun semuanya berjalan lancar.",
      date: DateTime(2025, 5, 3),
    ),
    DiaryEntry(
      title: "Menikmati Alam",
      content: "Aku menghabiskan waktu berjalan di taman. Rasanya menyenangkan berhubungan dengan alam setelah minggu yang sibuk.",
      date: DateTime(2025, 5, 3),
    ),
    DiaryEntry(
      title: "Rencana untuk Minggu Depan",
      content: "Hari ini aku mulai membuat rencana untuk minggu depan, memastikan agar segala sesuatunya lebih terorganisir.",
      date: DateTime(2025, 5, 3),
    ),

    // Tanggal 4 Mei 2025
    DiaryEntry(
      title: "Menjadi Lebih Baik",
      content: "Hari ini aku belajar untuk lebih menghargai waktu dan orang di sekitarku.",
      date: DateTime(2025, 5, 4),
    ),
    DiaryEntry(
      title: "Menyelesaikan Tantangan",
      content: "Aku berhasil menyelesaikan tantangan yang sulit hari ini, merasa bangga dengan pencapaian ini.",
      date: DateTime(2025, 5, 4),
    ),
    DiaryEntry(
      title: "Hari yang Penuh Pelajaran",
      content: "Hari ini penuh dengan pelajaran berharga. Aku belajar banyak tentang bagaimana menghadapi rintangan dengan bijak.",
      date: DateTime(2025, 5, 4),
    ),
    DiaryEntry(
      title: "Bertemu Teman Lama",
      content: "Aku bertemu dengan teman lama hari ini. Kami berbincang-bincang dan mengenang masa lalu dengan senyum yang penuh kenangan.",
      date: DateTime(2025, 5, 4),
    ),
  ];

  // Fungsi untuk mendapatkan entri yang sesuai dengan tanggal yang dipilih
  List<DiaryEntry> getEntriesForSelectedDate() {
    return entries.where((entry) {
      final entryDate = DateTime(entry.date.year, entry.date.month, entry.date.day);
      final selected = DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
      return entryDate == selected;
    }).toList();
  }

  void _updateEntry(DiaryEntry oldEntry, DiaryEntry newEntry) {
    setState(() {
      final index = entries.indexOf(oldEntry);
      if (index != -1) {
        entries[index] = newEntry;
      }
    });
  }

  void _deleteEntry(DiaryEntry entry) {
    setState(() {
      entries.remove(entry);
    });
  }

  @override
  Widget build(BuildContext context) {
    // Filter entri berdasarkan selectedDate
    List<DiaryEntry> selectedEntries = getEntriesForSelectedDate();

    return Scaffold(
      backgroundColor: const Color(0xFFF8D7D5),
      body: isDayView
          ? _buildDayView(selectedEntries) // Kirim entri yang sudah difilter
          : WeekView(
        onToggleView: () {
          setState(() {
            isDayView = true;
          });
        },
        currentNavIndex: currentNavIndex,
        onNavTap: (index) {
          setState(() {
            currentNavIndex = index;
          });
        },
        entries: entries, // Pass the entries here to WeekView
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => AddDiaryPage(selectedDate: selectedDate)),
          );
        },
        backgroundColor: const Color(0xFFB47878),
        elevation: 4,
        shape: const CircleBorder(),
        child: const Icon(Icons.add, color: Colors.white, size: 30),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: currentNavIndex,
        onTap: (index) {
          setState(() {
            currentNavIndex = index;
          });
        },
      ),
    );
  }

  Widget _buildDayView(List<DiaryEntry> dayEntries) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
          color: const Color(0xFFF8D7D5),
          child: SafeArea(
            bottom: false,
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      'My Diary',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    _buildToggleButton(),
                  ],
                ),
                const SizedBox(height: 20),
                _buildCalendar(),
              ],
            ),
          ),
        ),
        Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: ListView.builder(
              padding: const EdgeInsets.only(top: 24, bottom: 100),
              itemCount: dayEntries.length,
              itemBuilder: (context, index) {
                return _buildDayEntry(dayEntries[index]);
              },
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDayEntry(DiaryEntry entry) {
    return GestureDetector(
      onTap: () {
        // Navigate to detail page with the entry and update callback
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => DiaryDetailPage(
              entry: entry,
              onUpdate: _updateEntry,
              onDelete: _deleteEntry,
            ),
          ),
        );
      },
      child: Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12.withOpacity(0.05),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
            border: Border.all(color: Colors.grey.withOpacity(0.1)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  entry.content,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis, // tampilkan "..." jika terlalu panjang
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildToggleButton() {
    return Container(
      height: 44,
      width: 200,
      decoration: BoxDecoration(
        color: const Color(0xFFB47878).withOpacity(0.3),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => isDayView = true),
              child: Container(
                decoration: BoxDecoration(
                  color: isDayView ? const Color(0xFFB47878) : Colors.transparent,
                  borderRadius: BorderRadius.circular(22),
                ),
                alignment: Alignment.center,
                child: Text(
                  'Day',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: isDayView ? Colors.white : Colors.black87,
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: GestureDetector(
              onTap: () => setState(() => isDayView = false),
              child: Container(
                decoration: BoxDecoration(
                  color: !isDayView ? const Color(0xFFB47878) : Colors.transparent,
                  borderRadius: BorderRadius.circular(22),
                ),
                alignment: Alignment.center,
                child: Text(
                  'Week',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: !isDayView ? Colors.white : Colors.black87,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalendar() {
    List<String> days = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];

    // Tentukan tanggal awal minggu (misalnya, minggu ini dimulai dari tanggal 29 April 2025)
    DateTime weekStart = DateTime(2025, 4, 29);
    List<DateTime> weekDates = List.generate(7, (i) => weekStart.add(Duration(days: i)));

    return Column(
      children: [
        // Create a row of containers for day names to ensure consistent width and centering
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(7, (index) {
            return Container(
              width: 36,
              height: 24,
              alignment: Alignment.center,
              child: Text(
                days[index],
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: Colors.black87,
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 10),
        // Create a row of containers for the dates with same width as day containers
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: List.generate(7, (index) {
            if (index < weekDates.length) {
              DateTime date = weekDates[index];
              bool selected = date.day == selectedDate.day &&
                  date.month == selectedDate.month &&
                  date.year == selectedDate.year;

              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedDate = date; // Memperbarui selectedDate
                  });
                },
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: selected ? const Color(0xFFB47878) : Colors.transparent,
                    shape: BoxShape.circle,
                  ),
                  alignment: Alignment.center,
                  child: Text(
                    '${date.day}',
                    style: TextStyle(
                      color: selected ? Colors.white : Colors.black87,
                      fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 13,
                    ),
                  ),
                ),
              );
            } else {
              // Empty container to maintain spacing
              return Container(
                width: 36,
                height: 36,
              );
            }
          }),
        ),
      ],
    );
  }
}



class DiaryDetailPage extends StatefulWidget {
  final DiaryEntry entry;
  final Function(DiaryEntry, DiaryEntry) onUpdate;
  final Function(DiaryEntry) onDelete;

  const DiaryDetailPage({
    Key? key,
    required this.entry,
    required this.onUpdate,
    required this.onDelete,
  }) : super(key: key);

  @override
  State<DiaryDetailPage> createState() => _DiaryDetailPageState();
}

class _DiaryDetailPageState extends State<DiaryDetailPage> {
  late DiaryEntry _currentEntry;
  DateTime selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _currentEntry = widget.entry;
  }

  void _navigateToEdit() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditDiaryPage(
          entry: _currentEntry,
          onSave: (updatedEntry) {
            setState(() {
              // Update the local entry
              widget.onUpdate(_currentEntry, updatedEntry);
              _currentEntry = updatedEntry;
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8D7D5),
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.black87),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ),
          // Removed the date display section
          Expanded(
            child: Stack(
              children: [
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 80),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, -2))],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _currentEntry.title,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 16),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Text(
                            _currentEntry.content,
                            style: const TextStyle(fontSize: 16, color: Colors.black87, height: 1.5),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  bottom: 60,
                  right: 26,
                  child: Row(
                    children: [
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: RawMaterialButton(
                          onPressed: _navigateToEdit,
                          fillColor: const Color(0xFFB47878),
                          shape: const CircleBorder(),
                          elevation: 4.0,
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: RawMaterialButton(
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text("Hapus Catatan"),
                                content: const Text("Apakah kamu yakin ingin menghapus catatan ini?"),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text("Batal"),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      widget.onDelete(_currentEntry);
                                      Navigator.pop(context); // tutup dialog
                                      Navigator.pop(context); // balik ke WeekView
                                    },
                                    child: const Text("Hapus", style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            );
                          },
                          fillColor: Colors.redAccent,
                          shape: const CircleBorder(),
                          elevation: 4.0,
                          child: const Icon(
                            Icons.delete,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}