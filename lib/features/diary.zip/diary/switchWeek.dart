import 'package:flutter/material.dart';
import 'diary.dart';
import 'editDiary.dart';

class WeekView extends StatelessWidget {
  final VoidCallback onToggleView;
  final int currentNavIndex;
  final Function(int) onNavTap;
  final List<DiaryEntry> entries;

  const WeekView({
    Key? key,
    required this.onToggleView,
    required this.currentNavIndex,
    required this.onNavTap,
    required this.entries,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8D7D5),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'My Diary',
                        style: TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                      _buildToggleButton(),
                    ],
                  ),
                  const SizedBox(height: 20),
                  _buildWeekSelector(),
                ],
              ),
            ),
            // BODY
            Expanded(
              child: Container(
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                ),
                child: entries.isEmpty
                    ? const Center(
                  child: Text(
                    "Belum ada catatan minggu ini",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black54,
                    ),
                  ),
                )
                    : _buildWeekEntries(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToggleButton() {
    return Container(
      height: 44,
      width: 200,
      decoration: BoxDecoration(
        color: const Color(0xFFB47878).withOpacity(0.3),
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: onToggleView,
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(22),
                ),
                alignment: Alignment.center,
                child: const Text(
                  'Day',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w600,
                    color: Colors.black87,
                  ),
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFB47878),
                borderRadius: BorderRadius.circular(22),
              ),
              alignment: Alignment.center,
              child: const Text(
                'Week',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeekSelector() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left, color: Colors.black54),
          onPressed: () {
            // implement previous week
          },
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: const Color(0xFFB47878).withOpacity(0.2),
            borderRadius: BorderRadius.circular(16),
          ),
          child: const Text(
            'Jan 29 - Feb 05',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Colors.black87,
            ),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.chevron_right, color: Colors.black54),
          onPressed: () {
            // implement next week
          },
        ),
      ],
    );
  }

  Widget _buildWeekEntries() {
    // Group entries by date
    Map<String, List<DiaryEntry>> groupedEntries = {};

    // Create sample data for the week view based on image
    groupedEntries['Mon, Jan 29'] = [
      DiaryEntry(
        title: "Pengalaman Baru",
        content: "Pagi ini ketika matahari mulai menembus jendela kamarku, aku merasa semangat yang berbeda. Aku mencoba hal baru hari ini — menghadiri kelas seni melukis di taman kota. Awalnya gugup, tapi begitu kupegang kuas itu, aku merasa bebas. Rasanya menyenangkan keluar dari zona nyaman dan mencoba sesuatu yang benar-benar baru.",
        date: DateTime(2025, 1, 29),
      ),
    ];

    groupedEntries['Tue, Jan 30'] = [
      DiaryEntry(
        title: "Menahan Emosi",
        content: "Hari ini, amarahku seperti api kecil yang tersembunyi di balik kabut. Bukan ledakan besar, tetapi bara yang menyala perlahan. Sepanjang hari aku berusaha mengendalikannya, menarik napas dalam-dalam setiap kali terasa akan meluap. Perkataan tajam yang hampir terucap, kutahan di ujung lidah. Mungkin besok akan lebih baik, ketika pikiran lebih jernih dan hati lebih tenang.",
        date: DateTime(2025, 1, 30),
      ),
      DiaryEntry(
        title: "Pagi yang Cerah",
        content: "Pagi ini ketika matahari bersinar masuk melalui jendela, aku merasa semangat hidup kembali mengalir dalam darahku. Langit biru tanpa awan seolah menjanjikan hari yang penuh kemungkinan. Burung-burung berkicau riang di luar, seperti mengajakku untuk merayakan keindahan sederhana dalam hidup. Hari ini, aku bertekad untuk menghargai setiap momen dan menemukan kebahagiaan dalam hal-hal kecil.",
        date: DateTime.now(),
      ),
      DiaryEntry(
        title: "Petang yang Tenang",
        content: "Duduk di teras sambil menikmati petang yang tenang adalah cara favoritku mengakhiri hari. Semburat jingga di langit perlahan berganti menjadi ungu kemerahan, sementara suara jangkrik mulai terdengar dari kejauhan. Segelas teh hangat di tangan kiri, buku yang setengah terbuka di pangkuan. Waktu seolah melambat, memberiku ruang untuk bernapas dan merenung tentang semua yang telah terjadi hari ini, juga harapan untuk esok hari.",
        date: DateTime.now(),
      ),
    ];

    groupedEntries['Thu, Feb 01'] = [
      DiaryEntry(
        title: "Malam",
        content: "Malam ini sangat tenang, hanya suara jangkrik dan semilir angin yang menemani. Aku duduk di dekat jendela, melihat bintang-bintang yang perlahan muncul. Rasanya damai, jauh dari hiruk-pikuk siang hari. Dalam keheningan ini, aku merenung banyak hal — tentang harapan, tentang masa lalu, dan tentang siapa diriku sekarang.",
        date: DateTime(2025, 2, 1),
      ),
    ];

    groupedEntries['Fri, Feb 02'] = [
      DiaryEntry(
        title: "Cerita Singkat",
        content: "Pagi ini ketika matahari muncul perlahan, aku menemukan buku harian lama di laci meja. Aku membaca kembali catatan-catatan masa sekolah, dan tak sadar air mata menetes. Lucu sekaligus menyentuh, bagaimana perasaan masa lalu bisa terasa begitu nyata. Hari ini aku menulis cerita pendek berdasarkan kenangan itu.",
        date: DateTime(2025, 2, 2),
      ),
      DiaryEntry(
        title: "Perjalanan & Piknik",
        content: "Hari ini aku dan teman-teman kantor pergi piknik ke daerah pegunungan. Perjalanan cukup jauh, tapi udara segar dan tawa riang di sepanjang jalan membuat semuanya terasa ringan. Kami bercerita, berbagi makanan, dan menikmati panorama alam. Momen seperti ini mengingatkanku akan pentingnya kebersamaan.",
        date: DateTime(2025, 2, 2),
      ),
    ];

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: groupedEntries.length,
      itemBuilder: (context, index) {
        String date = groupedEntries.keys.elementAt(index);
        List<DiaryEntry> dayEntries = groupedEntries[date]!;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Date header
            Padding(
              padding: const EdgeInsets.only(bottom: 8, top: 16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE8F5E9),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Icon(
                      date.contains('Mon') ? Icons.calendar_today : Icons.calendar_month,
                      size: 16,
                      color: Colors.green[700],
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    date,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
            // Entries for this date
            ...dayEntries.map((entry) => _buildDayEntry(context, entry)
            ).toList(),
          ],
        );
      },
    );
  }

  Widget _buildDayEntry(BuildContext context, DiaryEntry entry) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DiaryDetailPage(
                entry: entry,
                onUpdate: (oldEntry, updatedEntry) {
                  // Tambahkan logika update jika dibutuhkan
                },
                onDelete: (deletedEntry) {
                  // Hapus entry dari entries dan panggil setState
                  // Tapi karena ini StatelessWidget, kamu perlu ubah jadi Stateful kalau mau langsung hapus
                  print("Catatan dihapus: ${deletedEntry.title}");
                },
              ),
            ),
          );
        },
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                color: Colors.black12.withOpacity(0.05),
                blurRadius: 4,
                offset: const Offset(0, 2),
              ),
            ],
            border: Border.all(color: Colors.grey.withOpacity(0.1)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  entry.content,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.black54,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

}
class DiaryDetailPage extends StatefulWidget {
  final DiaryEntry entry;
  final Function(DiaryEntry, DiaryEntry) onUpdate;
  final Function(DiaryEntry) onDelete;

  const DiaryDetailPage({
    Key? key,
    required this.entry,
    required this.onUpdate,
    required this.onDelete,
  }) : super(key: key);

  @override
  State<DiaryDetailPage> createState() => _DiaryDetailPageState();
}

class _DiaryDetailPageState extends State<DiaryDetailPage> {
  late DiaryEntry _currentEntry;

  @override
  void initState() {
    super.initState();
    _currentEntry = widget.entry;
  }

  void _navigateToEdit() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => EditDiaryPage(
          entry: _currentEntry,
          onSave: (updatedEntry) {
            setState(() {
              // Update the local entry
              widget.onUpdate(_currentEntry, updatedEntry);
              _currentEntry = updatedEntry;
            });
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8D7D5),
      body: Column(
        children: [
          SafeArea(
            bottom: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back, color: Colors.black87),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: Stack(
              children: [
                Container(
                  padding: const EdgeInsets.fromLTRB(16, 20, 16, 80),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
                    boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, -2))],
                  ),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(16, 20, 16, 490),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _currentEntry.title,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _currentEntry.content,
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                            height: 1.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                // Dua tombol edit dan hapus berdampingan
                Positioned(
                  bottom: 60,
                  right: 26,
                  child: Row(
                    children: [
                      // Tombol Edit
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: RawMaterialButton(
                          onPressed: _navigateToEdit,
                          fillColor: const Color(0xFFB87575),
                          shape: const CircleBorder(),
                          elevation: 4.0,
                          child: const Icon(
                            Icons.edit,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      // Tombol Delete
                      SizedBox(
                        width: 60,
                        height: 60,
                        child: RawMaterialButton(
                          onPressed: () {
                            showDialog(
                              context: context,
                              builder: (context) => AlertDialog(
                                title: const Text("Hapus Catatan"),
                                content: const Text("Apakah kamu yakin ingin menghapus catatan ini?"),
                                actions: [
                                  TextButton(
                                    onPressed: () => Navigator.pop(context),
                                    child: const Text("Batal"),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      widget.onDelete(_currentEntry);
                                      Navigator.pop(context); // tutup dialog
                                      Navigator.pop(context); // balik ke WeekView
                                    },
                                    child: const Text("Hapus", style: TextStyle(color: Colors.red)),
                                  ),
                                ],
                              ),
                            );
                          },
                          fillColor: Colors.redAccent,
                          shape: const CircleBorder(),
                          elevation: 4.0,
                          child: const Icon(
                            Icons.delete,
                            color: Colors.white,
                            size: 24,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}